package com.syne.life;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SyneLifeApplicationTests {

	@Test
	void contextLoads() {
	}

}
