package com.synechron.life.repo;

import org.springframework.stereotype.Repository;

@Repository
public interface SyneLifeRepository {

}
