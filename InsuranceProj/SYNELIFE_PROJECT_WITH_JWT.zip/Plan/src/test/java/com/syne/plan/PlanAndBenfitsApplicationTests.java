package com.syne.plan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanAndBenfitsApplicationTests {

	@Test
	void contextLoads() {
	}

}
