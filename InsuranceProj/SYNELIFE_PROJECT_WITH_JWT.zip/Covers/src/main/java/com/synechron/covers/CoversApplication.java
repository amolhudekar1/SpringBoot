package com.synechron.covers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoversApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoversApplication.class, args);
	}

}
